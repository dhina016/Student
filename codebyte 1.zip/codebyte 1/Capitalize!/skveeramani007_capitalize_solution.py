# Complete the solve function below.
def solve(s):
    a=s.title()
    return a