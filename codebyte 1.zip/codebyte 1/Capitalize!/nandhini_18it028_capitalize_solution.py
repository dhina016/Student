# Complete the solve function below.
a="hello world"
b=a.title()
print(b) 