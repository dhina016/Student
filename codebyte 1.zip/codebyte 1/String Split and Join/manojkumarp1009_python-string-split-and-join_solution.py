def split_and_join(line):
    # write your code here
    string = raw_input()
string = string.split(' ')
string = ('-').join(string)
print string
exit