def split_and_join(line):
    
 s1= "this is a string"
 s1=s1.split() 
 s2= "-". join(s1) 
 print(s2)