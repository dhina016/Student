def split_and_join(line):
    a="this is a string"
    a=a.split( )
    a="-".join(a)
    print(a)
    
    