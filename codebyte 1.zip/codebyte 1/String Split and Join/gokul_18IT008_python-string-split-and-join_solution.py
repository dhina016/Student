def split_and_join(line):
    # write your code here
    line = line.split(" ") 
    line='-'.join(line) 
    return line