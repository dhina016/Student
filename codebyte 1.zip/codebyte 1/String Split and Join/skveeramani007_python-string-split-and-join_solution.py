def split_and_join(line):
    line=line.split("")
    line="_".join(line)
    return line
