def split_and_join(line):
    s=line.split(" ")
    s="-".join(s)
    return s
    