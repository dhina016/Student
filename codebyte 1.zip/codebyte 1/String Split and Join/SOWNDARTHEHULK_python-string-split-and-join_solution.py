def split_and_join(line):
    line=line.split(" ")
    line='-'.jion(line)
    return line
