def split_and_join(line):
    # write your code here
    a=line.split(" ")
    a="-".join(a)
    return a